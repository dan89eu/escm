<?php
/**
* Language file for group management form text
*
*/
return array(

    'name'			=> 'Group Name',
    'slug'          => 'Slug',
    'general' 		=> 'General',
    'permissions'	=> 'Permissions',
    'users_exists' => 'users exists',
    'delete_group' => 'delete group',

);
