<?php
/**
* Language file for blog section titles
*
*/

return array(

    'title' => 'Title',
    'create'			=> 'Create New Blog Category',
    'edit' 				=> 'Edit Blog Category',
    'management' => 'Manage Blog Categories',
    'blogcategories' => 'Blog',
    'groups' => 'Groups',
    'categories' => 'Categories',
    'blogcategorylist' => 'Blog Categories List',


    
);
