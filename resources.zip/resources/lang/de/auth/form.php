<?php
/**
* Language file for form fields for user account management
*
*/

return array(

    'password'				=> 'Passwort',
    'email'				=> 'Email',
    'newemail'				=> 'Neue Email',
    'confirmemail'			=> 'Email bestätigen',
    'firstname'				=> 'Vorname',
    'lastname'				=> 'Nachname',
    'newpassword'			=> 'Neues Passwort',
    'website'				=> 'Webseite',
    'country'				=> 'Land',
    'gravataremail'			=> 'Gravatar Email',
    'changegravatar'			=> 'Avatar ändern auf Gravatar.com',
    'oldpassword'			=> 'Altes Passwort',
    'confirmpassword'			=> 'Passwort bestätigen',

);
