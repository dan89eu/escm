<?php

/**
* Language file for group delete modal
*
*/
return array(

    'title'         => 'Brisanje grupe',
    'body'			=> 'Da li ste sigurni da �elite obrisati ovu grupu? Nakon ove operacije nije mogu?e vratiti podatke.',
    'cancel'		=> 'Odustani',
    'confirm'		=> 'Obri�i',

);
