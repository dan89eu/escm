<?php
/**
* Language file for group section titles
*
*/

return array(

    'create'			=> 'Kreirane nove grupe',
    'edit' 				=> 'Izmjene grupe',
    'management'	=> 'Upravljanje grupama',

);
