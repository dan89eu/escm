<?php
/**
* Language file for group table headings
*
*/

return array(

    'id'         => 'Redni br.',
    'name'       => 'Naziv',
    'users'      => 'Br. korisnika',
    'created_at' => 'Kreirano',
    'actions'	 => 'Akcije',

);
