<?php
/**
* Language file for submit buttons across the site
*
*/
return array(

    'edit'    			=> 'Wijzig',
    'delete'  			=> 'Verwijder',
    'restore' 			=> 'Herstel',
    'publish' 			=> 'Publiceren',
    'save'	  			=> 'Opslaan',
    'submit'	  		=> 'Verstuur',
    'cancel'  			=> 'Cancel',
    'create'  			=> 'Creër',
    'back'    			=> 'Terug',
    'signin'  			=> 'Log in',
    'forgotpassword' 	=> 'Ik mijn mijn wachtwoord vergeten',
    'rememberme'		=> 'Onthoud mij',
    'signup'			=> 'Meld je aan',
    'update'			=> 'Update',

);
