<?php
/**
* Language file for blog category table headings
*
*/

return array(

    'id'         => 'Id',
    'name'       => 'Naam',
    'blogs'      => 'Aantal blogs',
    'created_at' => 'Gemaakt op',
    'actions'	 => 'Acties',

);
