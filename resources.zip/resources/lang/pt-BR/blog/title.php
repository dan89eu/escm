<?php
/**
* Language file for blog section titles
*
*/

return array(

	'title'			=> 'Título',

);
