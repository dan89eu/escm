<?php

/**
* Language file for blog delete modal
*
*/
return array(

    'body'			=> 'Tem certeza que quer apagar a Categoria do Blogue? Essa operação é irreversível.',
    'cancel'		=> 'Cancelar',
    'confirm'		=> 'Apagar',
    'title'         => 'Apagar Categoria de Blogue',

);
