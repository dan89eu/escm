<?php
/**
* Language file for blog category table headings
*
*/

return array(

    'id'         => 'Id',
    'title'       => 'Заголовок',
    'comments'      => 'No. комментария',
    'created_at' => 'Создано',
    'actions'	 => 'Действия',

);
