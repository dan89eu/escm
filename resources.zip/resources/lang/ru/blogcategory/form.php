<?php
/**
* Language file for group management form text
*
*/
return array(

    'name'			=> 'Наименования категории Блога',
    'general' 		=> 'Основная',
);
