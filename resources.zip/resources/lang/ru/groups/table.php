<?php
/**
* Language file for group table headings
*
*/

return array(

    'id'         => 'Id',
    'name'       => 'Наименование ',
    'users'      => 'No. пользователя',
    'created_at' => 'Создано',
    'actions'	 => 'Действия',

);
